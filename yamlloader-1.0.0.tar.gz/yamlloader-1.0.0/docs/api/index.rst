.. yamlloader documentation master file, created by
   sphinx-quickstart on Wed Dec 13 13:46:00 2017.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to yamlloader's documentation!
======================================

.. toctree::
   :titlesonly:
   :maxdepth: 1
   :caption: Contents:

   yamlloader


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
